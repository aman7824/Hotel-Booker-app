## Packages
react-day-picker | Date picker component for booking dates
date-fns | Date formatting and manipulation library

## Notes
Auth is handled via Replit Auth (OIDC).
Endpoints: /api/login, /api/logout, /api/auth/user
Use credentials: "include" for all requests.
